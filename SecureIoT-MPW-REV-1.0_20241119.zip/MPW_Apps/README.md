# Application Structure

This guide outlines how to create a simple application within the `src/` directory. The application folder and its main `.c` file should have the same name.

## Steps to Create the Application

1. Navigate to the `src/` directory.

2. Create a folder for the application. The folder name will also be the name of the `.c` file.

    Example:
    ```
    src/
    ├── hello/
    │   └── hello.c
    ```

3. Inside the newly created folder, create a `.c` file with the same name as the folder.

### Example: `hello` Application

- Folder: `src/hello/`
- File: `src/hello/hello.c`


### To run .c application
```bash
$ make PROGRAM=app_name
```
Note: app_name is the name of your application.