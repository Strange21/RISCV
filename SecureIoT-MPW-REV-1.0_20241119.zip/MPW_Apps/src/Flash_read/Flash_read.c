/**
 * @file Flash_read.c
 * @author Vishwajith.N.S (vishwajith@mindgrovetech.in)
 * @brief Example code to read data from flash memory through QSPI.
 * @version 1.0
 * @date 2024-10-29
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2024. All rights reserved.
 * 
 */

#include "io.h"        /*Included to access functions for basic IO operations such as printf,etc*/
#include "qspi_flash.h"/*Included to access QSPI Flash driver API's*/

void main(){
    uint8_t qspi_instance = 0;
    uint8_t data[16];
    uint8_t starting_address = 0x600;
    uint8_t data_length = 16;
    fastReadQuad(qspi_instance,data,starting_address,data_length);/*Read data from flash*/
    for(uint8_t i = 0;i<16;i++){
        printf("Data[%d] = %x\r \n",i,data[i]);
    }
    while(1);
}

