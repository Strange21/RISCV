/**
 * @file Flash_write.c
 * @author Vishwajith.N.S (vishwajith@mindgrovetech.in)
 * @brief Example code to write data into flash memory through QSPI.
 * @version 1.0
 * @date 2024-10-29
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2024. All rights reserved.
 * 
 */

#include "io.h"        /*Included to access functions for basic IO operations such as printf,etc*/
#include "qspi_flash.h"/*Included to access QSPI Flash driver API's*/

void main(){
    uint8_t qspi_instance = 0;
    uint8_t data[16] = {[0 ... 7] = 0x11,[8 ... 15] = 0x22};
    uint8_t starting_address = 0x600;
    uint8_t data_length = 16;
    writeEnable(qspi_instance);/*Enable write operation*/
    inputpageQuad(qspi_instance,data,starting_address,data_length);/*To write data to flash*/
    writeDisable(qspi_instance);/*Disable write operation*/
    printf("\n Successfully written in Flash");
    while(1);
}
