#include "io.h"         /*Included to access functions for basic IO operations such as printf,etc*/
#include "trng.h"       /*Included to access TRNG driver API's*/

void main(){
    uint8_t random_string[17];
    int req_sec_strength = 128;//Required security strength
    int no_of_bytes = 16;//No of bytes ti be generated
    uint8_t status;
    while(1){
    status = TRNG_Generate((void *)random_string,req_sec_strength,no_of_bytes);
    if(status == 0){
        random_string[16] = 0x00;
        printf("Generated random string :%s",random_string);
    }
}
}