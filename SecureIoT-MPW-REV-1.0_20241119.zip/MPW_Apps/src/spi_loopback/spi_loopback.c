#include "spi.h"
#include "io.h"

int main()
{ 
    SPI_Config_t config;

    config.spi_number = 3;
    config.pol = 0;
    config.pha = 0;
    config.prescale = 60;
    config.setup_time = 0;
    config.hold_time = 0;
    config.master_mode = MASTER;
    config.lsb_first = LSB_FIRST;
    config.comm_mode = FULL_DUPLEX;
    config.spi_size = 8;

    uint8_t tx_buff[12];
    uint8_t rx_buff[12];

    int len = sizeof(tx_buff) / sizeof(tx_buff[0]);
    for(int i = 0;i<12;i++){
        tx_buff[i] = i;
    }

    printf("len :%d\n", len);

    struct spi_buf tx_buf = { .buf = tx_buff, .len = len };
    struct spi_buf_set tx_bufs = { .buffers = &tx_buf, .count = 1};

    struct spi_buf rx_buf = { .buf = rx_buff, .len = len};
    struct spi_buf_set rx_bufs = { .buffers = &rx_buf, .count = 1};

    SPI_Configure(&config);
    int ret = SPI_Transceive(&config, &tx_bufs, &rx_bufs);

    for (int i = 0; i < 12; i++)
    {
        printf("\nReceived Data [%d] = %x", i, rx_buff[i]);
    }
    
    printf("completed transmission\n");
    return 0;
}