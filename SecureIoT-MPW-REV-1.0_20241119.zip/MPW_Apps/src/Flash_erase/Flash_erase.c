/**
 * @file Flash_erase.c
 * @author Vishwajith.N.S (vishwajith@mindgrovetech.in)
 * @brief Used to erase whole chip through QSPI.
 * @version 1.0
 * @date 2024-10-29
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2024. All rights reserved.
 * 
 */

#include "io.h"        /*Included to access functions for basic IO operations such as printf,etc*/
#include "qspi_flash.h"/*Included to access QSPI Flash driver API's*/

void main(){
uint8_t sr,fsr;
        uint8_t qspi_instance = 0;
        printf("Wait Chip Erase in Progress!!");
        writeEnable(qspi_instance);/*Enable write operation*/
        chipErase(qspi_instance);/*Send chip erase command*/
        writeDisable(qspi_instance);/*Disable write operation*/
        uint8_t temp = 0;
        while(1)
        {
        temp =  readFlagStatusRegister(qspi_instance);
        sr = readStatusRegister1(qspi_instance);
        temp = temp & (1<<7);
        if(temp == (1<<7)&&(sr == 0)){/*Wait till ready bit is set,used to check if erase operation is in progress*/
            break; 
        }
    }
    printf("Chip Erase Complete!"); 
}