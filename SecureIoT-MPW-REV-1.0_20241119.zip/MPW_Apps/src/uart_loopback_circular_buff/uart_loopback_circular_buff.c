/**
 * @file uart_loopback
 * @author VigneshKumar.J (vigneshkumar@mindgrovetech.in)
 * @brief Example code uart loopback with builtin buffer.
 * @version 1.0
 * @date 2024-10-30
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2024. All rights reserved.
 * 
 */
#include"uart.h" /*Included to access UART peripheral API's*/
#include"io.h"  /*Included to access functions for basic IO operations such as printf,etc*/
#include"gptimer.h" /*Included to access GPTimer peripheral API's*/
void main()
{
    UART_Config_t uart; /*Structure variable which hold the UART's specifications */
    UART_Config_t *uart_config=&uart; /*Creating a pointer to the above stucture variable*/
    uart_config->uart_num=2; /*Specifies the UART instance*/
    uart_config->baudrate=115200; /*Specifies the baudrate*/
    uart_config->char_size=8; /*Specifies the Char size*/
    uart_config->delay=0;/*Specifies the delay*/
    uart_config->parity=0;/*Specifies the parity*/
    uart_config->stop_bits=1;/*Specifies the stopbits*/
    uart_config->buffer_enable=UART_CIRCULAR_BUFF;/*Enable the circular buffer*/
    UART_Init(uart_config);/* Initializing the particular uart instance */
    char str[100] = "MINDGROVE";/*Declared a string and which is going to transmitted */
    int len = StrLen(str); /*Finding the length of the string*/
    while(1)/*Transmit and receive the above string continuously*/
    {
        char new[100];/*Declared a string variable to receive */
        UART_Write(uart_config,str,len); /*Transmitting the data via the specified UART instance*/
        UART_Buffer_Read_String(uart_config,new); /*Read all the data in Circular buffer*/
        printf("\nString is :%s\n", new);/*Printing the data in that has been received*/

    }
}
