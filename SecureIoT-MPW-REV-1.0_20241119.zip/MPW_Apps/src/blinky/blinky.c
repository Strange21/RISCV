#include <stdio.h>
#include "gpio.h"
#include <stdlib.h>
#include "secure_iot.h"

int main()
{
    #define GPIO_PIN_0 14
    #define GPIO_PIN_1 1
    #define GPIO_PIN_2 2

    GPIO_Config(1, 3, GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2);

    while (1)
    {
        // GPIO_Pin_Clear(3, GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2);
        // GPIO_Pin_Set(3, GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2);
        GPIO_Pin_Toggle(3, GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2);
        GPT_Delay_Millisecs_H(50);
        printf("\n blinking");

    }
    

}