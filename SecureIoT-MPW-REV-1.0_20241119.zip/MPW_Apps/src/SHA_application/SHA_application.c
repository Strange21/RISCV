#include "io.h"         /*Included to access functions for basic IO operations such as printf,etc*/
#include "sha256.h"       /*Included to access TRNG driver API's*/

void main(){
    uint8_t hash_digest[33];
    char input_text[45] = "The quick brown fox jumps over the lazy dog.";
    SHA256_Single_Run(hash_digest,input_text,(45*8));
    hash_digest[32] = 0x00;
    printf("\nHash digest : %s",hash_digest);
}