#include "pwm.h"
#include "log.h"
#include "pinmux.h"
#include "secure_iot.h"

int main()
{   
    int act_duty;
    PWM_Config_t config;
    config.duty = 0x0064;
    config.period = 0x0064;
    config.interrupt_mode = no_interrupt;
    config.change_output_polarity = false ;
    config.prescalar_value = 0x009;
    config.deadband_delay = 0x0005;
    config.value = PWM_OUTPUT_ENABLE;
    //*pinmux_config_reg = 0x40300;

    PWM_Init(&config, 2, 0,6);
    PWM_Start(&config, 2, 0,6);
    printf("end\n");
    return 0;
}
