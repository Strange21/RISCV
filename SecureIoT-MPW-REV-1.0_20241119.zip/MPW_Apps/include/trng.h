#ifndef TRNG_H
#define TRNG_H
#include<stdint.h>
uint32_t TRNG_Generate(void * output,int req_sec_strength,int no_of_bytes);
#endif