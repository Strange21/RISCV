

/***************************************************************************
 * Project               	    : shakti devt board
 * Name of the file	            : pwmv2.h
 * Brief Description of file    : Header file for PWM V2 Driver.
 * Name of Author    	        : Sathya Narayanan, Kotteeswaran
 * Email ID                     : kottee.off@gmail.com

 Copyright (C) 2021  IIT Madras. All rights reserved.

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <https://www.gnu.org/licenses/>.
***************************************************************************/
/**
 * @file pwmv2.c
 * @project shakti devt board
 * @brief Header file for PWM Driver.
 */


#ifdef __cplusplus
extern "C" {
#endif

#include<stdbool.h>
#include <stdint.h>


#define PERIOD_REGISTER_MAX   0xFFFFFFFF
#define DUTY_REGISTER_MAX         0xFFFFFFFF
#define CONTROL_REGISTER_MAX          0x0000FFFF
#define DEADBAND_DELAY_REGISTER_MAX   0x0000FFFF
#define PWM_MAX_COUNT 8

#define PWM_0 0
#define PWM_1 1 
#define PWM_2 2 
#define PWM_3 3
#define PWM_4 4 
#define PWM_5 5 
#define PWM_6 6
#define PWM_7 7

// Control Register Individual Bits
#define PWM_ENABLE                      0x00000001
#define PWM_START                       0x00000002
#define PWM_OUTPUT_ENABLE               0x00000004
#define PWM_OUTPUT_POLARITY             0x00000008
#define PWM_COUNTER_RESET               0x00000010
#define PWM_COMP_OUTPUT_ENABLE          0x00000020
#define PWM_HALFPERIOD_INTERRUPT_ENABLE 0x00000040
#define PWM_FALL_INTERRUPT_ENABLE       0x00000080
#define PWM_RISE_INTERRUPT_ENABLE       0x00000100
#define PWM_HALFPERIOD_INTERRUPT        0x00000200
#define PWM_FALL_INTERRUPT              0x00000400
#define PWM_RISE_INTERRUPT              0x00000800
#define PWM_UPDATE_ENABLE               0x00001000


typedef enum
{
  rise_interrupt,       //Enable interrupt only on rise
  fall_interrupt,       //Enable interrupt only on fall
  halfperiod_interrupt,     //Enable interrupt only on halfperiod
  rise_fall_interrupt,      //Enable interrupt on rise and fall
  fall_halfperiod_interrupt,    //Enable interrupt on fall and halfperiod
  rise_halfperiod_interrupt,    //Enable interrupt on rise and halfperiod
  rise_fall_halfperiod_interrupt,   //Enable interrupt on rise, fall and halfperiod
  no_interrupt        //Disable interrupts
}pwm_interrupt_modes;

typedef struct 
{
  int pwm_number;
  uint32_t duty;
  uint32_t period;
  uint32_t value;
  int pin_number;
  int val;
  bool update;
  pwm_interrupt_modes interrupt_mode;
  bool change_output_polarity;
  uint16_t prescalar_value;
  uint32_t deadband_delay;
}PWM_Config_t;


//function prototype
void PWM_Init(PWM_Config_t *config,int, ...);
void PWM_Set_Prescalar_Value(PWM_Config_t *config,int, int[]);
void PWM_Configure(PWM_Config_t *config,int, int[]); 
void PWM_Start(PWM_Config_t *config,int, ...);
int pwm_Set_Control(PWM_Config_t *config);

void PWM_Clear(PWM_Config_t *config);
void PWM_Stop(PWM_Config_t *config,int, ...);

void PWM_Set_Duty_Cycle(PWM_Config_t *config);
void PWM_Set_Periodic_Cycle(PWM_Config_t *config);
int PWM_Set_Deadband_Delay(PWM_Config_t *config);

// void analogWrite(PWM_Config_t *config);
int CONFIGURE_Control(PWM_Config_t *config);

void PWM_RESET_All();

void PWM_Update(PWM_Config_t *config);
void PWM_Show_Values(PWM_Config_t *config);
void PWM_Show_Frequency(PWM_Config_t *config);
void PWM_Isr_Handler0();
void PWM_Isr_Handler1();
void PWM_Isr_Handler2();
void PWM_Isr_Handler3();
void PWM_Isr_Handler4();
void PWM_Isr_Handler5();

#ifdef __cplusplus
}
#endif
