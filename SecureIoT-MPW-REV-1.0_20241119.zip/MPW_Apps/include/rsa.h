/**************************************************************************
 * Project                      : Mindgrove Silicon
 * Name of the file             : rsa_driver.h
 * Brief Description of file    : Contains the header files for rsa driver.
 * Name of Author               : Siddhanth Ramani
 * Email ID                     : siddhanth@mindgrovetech.in

 Copyright (C) 2021 Mindgrovetech Pvt Ltd. All rights reserved.
 ***************************************************************************/
/**
  @file rsa_driver.h
  @brief Contains the header files for rsa driver.
*/

#ifndef RSA_DRIVER_INCLUDED
#define RSA_DRIVER_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

// Includes
#include "io.h"
#include <tommath.h>

// Padding mode structure
typedef struct{
    int padding_mode;
    unsigned char * label;    
    __uint64_t label_length;
} struct_rsa_padding;


void input_to_rsa_prepend_zero(__uint64_t *load_input, unsigned char *input, int input_len);


void load_to_rsa(__uint64_t *rsa_reg_to_load, __uint64_t *load_input);


unsigned char * get_rsa_output(__uint64_t * rsa_output, volatile __uint64_t * rsa_output_reg_64);


void do_checks_rsa(unsigned char *mod_text
                    , long int input_len_bits, long int exp_len_bits, long int mod_len_bits
                    , struct_rsa_padding rsa_padding);


void run_rsa_2048(__uint64_t *rsa_output
                              , unsigned char *input_text, unsigned char *exp_text, unsigned char *mod_text
                              , long int input_len_bits, long int exp_len_bits, long int mod_len_bits
                              , bool encrypt
                              , struct_rsa_padding rsa_padding);


#ifdef __cplusplus
}
#endif

#endif
