/**
 * Project                           : Secure IoT SoC
 * Name of the file                  : gpio.h
 * Brief Description of file         : Header to Standard gpio driver
 * Name of Author                    : Kapil Shyam. M
 * Email ID                          : kapilshyamm@gmail.com
 * 
 * @file gpio.h
 * @author Kapil Shyam. M (kapilshyamm@gmail.com)
 * @brief This is a Baremetal GPIO Driver's Header file for Mindgrove Silicon's GPIO Peripheral
 * @version 0.2
 * @date 2023-06-20
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2023. All rights reserved.
 * 
 */

#include <stdint.h>
#include "platform.h"

#ifdef __cplusplus
extern "C" {
#endif

#define GPIO_DIRECTION_CNTRL_REG  (GPIO_START + (0 * GPIO_OFFSET ))
#define GPIO_DATA_REG             (GPIO_START + (1 * GPIO_OFFSET ))
#define GPIO_SET_REG              (GPIO_START + (2 * GPIO_OFFSET ))
#define GPIO_CLEAR_REG            (GPIO_START + (3 * GPIO_OFFSET ))
#define GPIO_TOGGLE_REG           (GPIO_START + (4 * GPIO_OFFSET ))
#define GPIO_QUAL_REG             (GPIO_START + (5 * GPIO_OFFSET ))
#define GPIO_INTERRUPT_CONFIG_REG (GPIO_START + (6 * GPIO_OFFSET ))

#define GPIO_IN  0
#define GPIO_OUT 1
#define GPIO_QUAL_MAX_CYCLES 15
#define ALL_GPIO_PINS -1

/**
 * @fn GPIO_Config(int direction, int no_of_pins, ...)
 *
 * @brief The function `GPIO_Config` initializes the GPIO instance and set the direction.
 * 
 * @details It is used to initializes the GPIO instance and set the direction of a GPIO pin 
 * which configure the GPIO port as input or output.  
 * 
 * @param direction The direction parameter is an integer value that specifies the direction of the
 * GPIO pin. It can be either 0 or 1, where 0 represents input and 1 represents output.
 * 
 * @param no_of_pins The `no_of_pins` parameter specifies the number of pins that you want to set in
 * the GPIO_DIRECTION register.
 */
void GPIO_Config(int direction, int no_of_pins, ...);

/**
 * @fn GPIO_Pin_Set(int no_of_pins, ...)
 * 
 * @brief The function `GPIO_Pin_Set` sets multiple GPIO pins based on the input arguments provided.
 * 
 * @details It is used to set the value of a GPIO pin in a GPIO instance, it also sets for multiple 
 * GPIO pins.
 * 
 * @param no_of_pins The `no_of_pins` parameter specifies the number of pins that you want to set in
 * the GPIO_SET register.
 */
void GPIO_Pin_Set(int no_of_pins, ...);

/**
 * @fn GPIO_Pin_Clear(int no_of_pins, ...)
 * 
 * @brief The function `GPIO_Pin_Clear` clears multiple GPIO pins based on the input arguments provided.
 * 
 * @details It is used to clear the value of a GPIO pin in a GPIO instance, it also clears for multiple 
 * GPIO pins.
 * 
 * @param no_of_pins The `no_of_pins` parameter specifies the number of pins that you want to clear in
 * the GPIO_CLEAR register.
 */
void GPIO_Pin_Clear(int no_of_pins, ...);

/**
 * @fn GPIO_Pin_Toggle(int no_of_pins, ...)
 * 
 * @brief The function `GPIO_Pin_Toggle` toggles multiple GPIO pins based on the input arguments provided.
 * 
 * @details It is used to toggle the value of a GPIO pin in a GPIO instance, it also toggle for multiple 
 * GPIO pins.
 * 
 * @param no_of_pins The `no_of_pins` parameter specifies the number of pins that you want to toggle in
 * the GPIO_TOGGLE register.
 */
void GPIO_Pin_Toggle(int no_of_pins, ...);

/**
 * @fn void gpio_interrupt_config(unsigned long gpio_pin, int low_ena)
 *
 * @brief The function `GPIO_Interrupt_Config` configures the interrupt for a specific GPIO pin 
 * 
 * @details It is used to configure the interrupt for GPIO pins based on whether it is 
 * active low or active high.
 * 
 * @param gpio_pin The pin number for which the interrupt configuration is being set.
 *
 * @param low_ena This parameter is a boolean value that determines whether the interrupt is active low
 * or active high. If it is set to true (non-zero), the interrupt is active low, and if it is set to
 * false (zero), the interrupt is active high.
 */
void GPIO_Interrupt_Config(unsigned long gpio_pin, int low_ena);

/**
 * @fn long int GPIO_Pin_State_Read()
 *
 * @brief The function `GPIO_Pin_State_Read` returns the value of the data register in a GPIO instance.
 * 
 * @details It is used to return the value of the GPIO_DATA register
 * 
 * @return It returns the value of the `data` register of the `gpio_instance`. 
 */
long int GPIO_Pin_State_Read();

/**
 * @fn GPIO_Read_Pin_Status(unsigned long gpio_pin)
 * 
 * @brief The function `GPIO_Read_Pin_Status` reads the status of GPIO instance.
 * 
 * @details It is used to read the status of the specific pin in the GPIO instance
 * 
 * @param gpio_pin The pin number to read the status from.
 * 
 * @return It returns 1 if the pin is set (high), 0 if the pin is cleared (low).
 */
int GPIO_Read_Pin_Status(unsigned long gpio_pin);

/**
 * @fn void gpio_write_data_register(unsigned long data_word)
 *
 * @brief The function `GPIO_Pin_State_Write` sets the data register of a GPIO instance to a given data.
 * 
 * @details It is used to sets the data register of a GPIO instance to a given data.
 * 
 * @param data_word It represents the data to be written to the data register of a GPIO module. The data register 
 * is a hardware register that holds the current state of the GPIO pins. Writing to this register sets the output
 * values of the GPIO pins.
 */
void GPIO_Pin_State_Write(unsigned long data_word);

#ifdef __cplusplus
}
#endif
