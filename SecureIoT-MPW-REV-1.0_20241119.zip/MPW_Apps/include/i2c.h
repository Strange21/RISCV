/**
 * Project                           : Secure IoT SoC
 * Name of the file                  : i2c_driver.c
 * Brief Description of file         : This is a Baremetal I2C Driver file for Mindgrove Silicon's I2C Peripheral.
 * Name of Author                    : Vishwajith.N.S 
 * Email ID                          : vishwajithns6@gmail.com
 * 
 * @file i2c_v2_driver.c
 * @author Vishwajith .N.S (vishwajithns6@gmail.com)
 * @brief This is a Baremetal I2C Driver file for Mindgrove Silicon's I2C Peripheral.
 * @version 0.2
 * @date 2023-07-08
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2023. All rights reserved.
 * 
 */
#ifndef I2C_H
#define I2C_H
#ifdef __cplusplus
extern "C" {
#endif

#include<stdint.h>
#include"errors.h"
#define START_BIT 1<<1
#define NO_START_BIT 0
#define STOP_BIT 1<<2
#define REPEATED_START 0
#define I2C0 0
#define I2C1 1


/**
 * @fn I2C_Init(uint8_t instance_number,uint32_t clock_frequency)
 * 
 * @brief Used to set clock frequency for I2C communication.
 * 
 * @param instance_number The parameter \a instance_number is an unsigned integer that represents the I2C instance number.
 * @param clock_frequency The parameter \a clock_frequency is an unsigned integer that represents the clock frequency of I2C communication.
 * 
 * @return 0 when successfully initialised ENODEV when device not found.
 */
uint32_t I2C_Init(uint8_t instance_number,uint32_t clock_frequency);

/**
 * @fn I2C_Transmit(uint32_t instance_number,uint8_t slave_address,uint8_t *data,uint8_t len)
 * 
 * @brief Used to send data to slave through I2C communication.
 * 
 * @param instance_number The parameter \a instance_number is an unsigned integer that represents the I2C instance number.
 * @param slave_address The parameter \a slave_address is an 7 bit address that represents the I2C slave address.
 * @param data The parameter \a data is an pointer to array which has data to be sent.
 * @param length The parameter \a length is the length for which has data to be sent from data array.
 * @param mode The parameter \a mode is used to set whether to send start bit and stop bit in transaction.
 * 
 * @return 0 if successfull transmission and NOACK is no acknowledgement is recieved.
 */
uint32_t I2C_Transmit(uint32_t instance_number,uint8_t slave_address,uint8_t *data,uint8_t length,uint8_t mode);

/**
 * @fn I2C_Recieve(uint32_t instance_number,uint8_t slave_address,uint8_t *data,uint8_t len)
 * 
 * @brief Used to send data to slave through I2C communication.
 * 
 * @param instance_number The parameter \a instance_number is an unsigned integer that represents the I2C instance number.
 * @param slave_address The parameter \a slave_address is an 7 bit address that represents the I2C slave address.
 * @param data The parameter \a data is an pointer to array which has data to be sent.
 * @param length The parameter \a length is the length for which has data to be sent from data array.
 * @param mode The parameter \a mode is used to set whether to send start bit and stop bit in transaction.
 * 
 * @return 0 if successfull transmission  and NOACK is no acknowledgement is recieved.
 */
uint32_t I2C_Recieve(uint32_t instance_number,uint8_t slave_address,uint8_t *data,uint8_t length,uint8_t mode);

#ifdef __cplusplus
}
#endif
#endif