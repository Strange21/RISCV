/**
 * Project                           : Secure IoT SoC
 * Name of the file                  : gptimer.h
 * Brief Description of file         : Header to Standard gp_timer driver
 * Name of Author                    : Suneeth D, Shri Mahaalakshmi S J
 * Email ID                          : suneethdamodharan@gmail.com, mahaalakshmi@mindgrovetech.in
 * 
 * @file gptimer.h
 * @author Suneeth D (suneethdamodharan@gmail.com)
 * @author Shri Mahaalakshmi S J (mahaalakshmi@mindgrovetech.in)
 * @brief This is a Baremetal GP_TIMER Driver's header file for Mindgrove Silicon's General Purpose Timer module.
 * @version 0.2
 * @date 2024-09-20
 * 
 * @copyright Copyright (c) Mindgrove Technologies Pvt. Ltd 2023. All rights reserved.
 * 
 */

#ifndef GPT_H
#define GPT_H

#include <stdint.h>
#include "secure_iot.h"
#include "plic.h"
#include "log.h"

#ifdef __cplusplus
extern "C" {
#endif

/*! General Purpose Timer*/
#define GPT_MAX_COUNT 4
#define GPT_BASE_OFFSET 0x00000020
#define GPT_BASE_ADDRESS 0x00044200
#define GPT0_BASE_ADDRESS 0x00044200
#define GPT0_END_ADDRESS 0x0004421F
#define GPT1_BASE_ADDRESS 0x00044220
#define GPT1_END_ADDRESS 0x0004423F
#define GPT2_BASE_ADDRESS 0x00044240
#define GPT2_END_ADDRESS 0x0004425F
#define GPT3_BASE_ADDRESS 0x00044260
#define GPT3_END_ADDRESS 0x0004427F

/*! Registers of each GP_TIMER*/
#define CTRL_REG         0x00044200
#define CLK_CNTRL_REG    0x00044204
#define CNTR_VAL_REG     0x00044208
#define RPTD_CNT_REG     0x0004420C
#define DUTY_CYC_REG     0x00044210
#define PERIOD_REG       0x00044214
#define CAPT_IP_REG      0x00044218

/* Bit Specifications of each GP_TIMER's register*/
/* Control Register */
#define GPT_EN              (1<<0)
#define GPT_MODE(x)         (x<<2)
#define GPT_OUTPUT_EN       (1<<4)
#define COUNT_RESET         (1<<5)
#define CONTIN_CNT_EN       (1<<6)
#define PWM_FALL_INTR_EN    (1<<7) 
#define PWM_RISE_INTR_EN    (1<<8)
#define CNTR_OFLOW_INTR_EN  (1<<9)
#define CNTR_UFLOW_INTR_EN  (1<<10)
#define CAPTURE_IP(x)       (x<<15) 

/* Clock Control Reg*/
#define clk_src (0<<0)
#define clk_prescalar(x)    (x<<1)
#define clk_update_en(x)    (x<<17)

/* Duty Cycle Reg*/
#define DUTY_CYC_VAL(x)     (x<<0)

/* Period Reg*/
#define PRD_VAL(x)          (x<<0)

typedef struct 
{
    // The parameter gpt_num is an integer that represents the GPT instance number.
    // @note gpt_num value must be always less than GPT_MAX_COUNT.
    int gpt_num;

    // The parameter mode is an integer that sets tCONTIN_CNT_ENhe mode of gp_timer
    // @note mode value must be always in the range 0<=mode<4.
    int mode;

    // The paramter interrupt_en is used as a bool to enable the interrupt
    int interrupt_en;

    // The parameter period is an integer that sets the period of gp_timer till which it needs to count
    int period;

    // The parameter prescalar is an integer that sets the prescalar value with which the clock gets divided
    int prescalar;

    // The parameter dutycycle is an integer that sets the duty cycle value for the pulse generated in PWM
    int dutycycle;

    // The paramter cnt_en is integer that enables continous count mode of the gptimer
    int cnt_en;

    // The parameter capture_val is an integer that sets the input value to be captured
    int capture_val;

    // The parameter output_en is an integer that sets the output_enable high in the control and status register
    int output_en;
}GPTIMER_Config_t;

/**
 * @fn void GPT_Init(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Init` initialises the gp_timer with different modes and configures necessary registers.
 * 
 * @details It is used to select the specific GPT instance, set the mode, set the prescalar, set the dutycycle, enable
 * continous count and set the input bit to be captured.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Init` function is a struct that
 * contains several properties related to configuring a General Purpose Timer (GPT).It has the following properties: 
 * gpt_num, mode, interrupt_en, period, prescalar, dutycycle, cnt_en, capture_val, output_en.
 */
void GPT_Init(GPTIMER_Config_t *gptimer);

/**
 * @fn void GPT_Set_Period(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Set_Period` sets the period for the specific gpt instance
 * 
 * @details It is used to set the threshold value for the specific gpt instance to count 
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Set_Period` function is a struct that
 * contains gpt_num, period.
 */
void GPT_Set_Period(GPTIMER_Config_t *gptimer);

/**
 * @fn void GPT_Set_Dutycycle(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Set_Dutycycle` sets the duty cycle for the specific gpt instance
 * 
 * @details It is used to set the duty cycle for the pulse generated in PWM mode by 
 * the specific GPT instance. 
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Set_Dutycycle` function is a struct that
 * contains gpt_num, prescalar, dutycycle.
 */
void GPT_Set_Dutycycle(GPTIMER_Config_t *gptimer);

/**
 * @fn int GPT_Read_Dutycycle(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Dutycycle` reads the value of the duty cycle register.
 * 
 * @details It is used to read the value of duty cycle of a specific gpt instance at any time during its 
 * counting process. 
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Dutycycle` function is a struct that
 * contains gpt_num.
 */
int GPT_Read_Dutycycle(GPTIMER_Config_t *gptimer);

/**
 * @fn void GPT_Set_Prescalar(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Set_Prescalar` sets the prescalar value for the specific gpt instance
 * 
 * @details It is used to set the prescalar value for the specific gpt instance by a factor which the clk is divided
 * and the counter counts the value of clock cycles accordingly. 
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Set_Prescalar` function is a struct that
 * contains gpt_num, prescalar.
 */
void GPT_Set_Prescalar(GPTIMER_Config_t *gptimer);

/**
 * @fn void GPT_Update_Enable(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Update_Enable` checks the clock control register for specified register
 * 
 * @details It is used to checks and updates the clock control register for a specified GPTIMER
 * configuration.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Update_Enable` function is a struct that
 * contains gpt_num.
 */
void GPT_Update_Enable(GPTIMER_Config_t *gptimer);

/**
 * @fn int GPT_Read_Counter_Val(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Counter_Val` reads the value of the counter.
 * 
 * @details It is used to read the value of counter of a specific gpt instance at any time during its 
 * counting process. 
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Counter_Val` function is a struct that
 * contains gpt_num.
 *  
 * @return returns a 32-bit counter value that is currently stored in the counter register
 */
int GPT_Read_Counter_Val(GPTIMER_Config_t *gptimer);

/**
 * @fn int GPT_Read_ReptdCount(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_ReptdCount` reads the value of repeated counts.
 * 
 * @details It is used to read the value of repeated counts counted by the counter of specific 
 * GPT instance when continous count is enabled
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_ReptdCount` function is a struct that
 * contains gpt_num.
 * 
 * @return returns a 32-bit repeated count value that is currently stored in the Repeated_Count register
 */
int GPT_Read_ReptdCount(GPTIMER_Config_t *gptimer);

/**
 * @fn int GPT_Read_Captured_Val(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Captured_Val` reads captured counter value
 * 
 * @details It is used to read the value of counter value captured when a desired input is captured
 *  at a gpio pin
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Captured_Val` function is a struct that
 * contains gpt_num.
 * 
 * @return returns a 32-bit counter value that is captured and currently stored in Capture_register
 */
int GPT_Read_Captured_Val(GPTIMER_Config_t *gptimer);

/**
 * @fn int GPT_Read_Overflow_Interrupt(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Overflow_Interrupt` reads the overflow interrupt signal generated
 * 
 * @details It is used to read the counter overflow interrupt generated once the counter reaches the threshold value.
 * The function waits till the overflow interrupt signal is generated in the control register.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Overflow_Interrupt` function is a struct that
 * contains gpt_num.
 * 
 * @return returns a bool value of True when the counter overflow interrupt is generated in Control_register
 */
int GPT_Read_Overflow_Interrupt(GPTIMER_Config_t *gptimer);

/**
 * @fn int GPT_Read_Underflow_Interrupt(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Underflow_Interrupt` reads the underflow interrupt signal generated
 * 
 * @details It is used to read the counter underflow interrupt generated once the counter reaches the threshold value.
 * The function waits till the underflow interrupt signal is generated in the control register.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Underflow_Interrupt` function is a struct that
 * contains gpt_num.
 * 
 * @return returns a bool value of True when the counter underflow interrupt is generated in Control_register
 */
int GPT_Read_Underflow_Interrupt(GPTIMER_Config_t *gptimer);

/**
 * @fn GPT_Read_Fall_Interrupt(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Fall_Interrupt` reads the PWM Falling Edge interrupt signal generated
 * 
 * @details It is used to read the Falling Edge interrupt signal generated for every Falling Edge of 
 * the generated PWM pulse.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Fall_Interrupt` function is a struct that
 * contains gpt_num.
 * 
 * @return a bool value of True when the counter underflow interrupt is generated in Control_register
 */
int GPT_Read_Fall_Interrupt(GPTIMER_Config_t *gptimer);

/**
 * @fn GPT_Read_Rise_Interrupt(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Read_Rise_Interrupt` reads the PWM Rising Edge interrupt signal generated
 * 
 * @details It is used to read the Rising Edge interrupt signal generated for every Rising Edge of 
 * the generated PWM pulse.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Read_Rise_Interrupt` function is a struct that
 * contains gpt_num.
 * 
 * @return a bool value of True when the counter underflow interrupt is generated in Control_register
 */
int GPT_Read_Rise_Interrupt(GPTIMER_Config_t *gptimer);

/**
 * @fn void GPT_Reset(GPTIMER_Config_t *gptimer)
 * 
 * @brief The function `GPT_Reset` resets the specific GPT instance
 * 
 * @details It is used to clear all the interrupts and counter values and resets the mode of the specific
 * GPT instance.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Reset` function is a struct that
 * contains gpt_num.
 */
void GPT_Reset(GPTIMER_Config_t *gptimer);

/**
 * @fn void GPT_Delay_Milliseconds(GPTIMER_Config_t *gptimer, uint32_t delay)
 * 
 * @brief The function `GPT_Delay_Milliseconds` generates hardware delay in milliseconds.
 * 
 * @details It initializes a general-purpose timer with a specified period and prescalar, 
 * then waits for a specified delay in milliseconds.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Delay_Milliseconds` function is a struct that
 * contains gpt_num, mode, interrupt_en, period, prescalar, dutycycle, cnt_en, capture_val, output_en.
 * 
 * @param delay The `delay` parameter in the `GPT_Delay_Milliseconds` function represents the time
 * delay in milliseconds. This function calculates the necessary period and prescalar values based on the provided 
 * delay to configure the timer accordingly.
 */
void GPT_Delay_Milliseconds(GPTIMER_Config_t *gptimer, uint32_t delay);

/**
 * @fn void GPT_Delay_Millisecs_H(uint32_t delay)
 * 
 * @brief The function `GPT_Delay_Millisecs_H` generates hardware delay in milliseconds
 * 
 * @details The function `GPT_Delay_Millisecs_H` initializes a general-purpose timer with a specified 
 * delay in milliseconds and waits until the timer reaches zero.
 * 
 * @param delay The `delay` parameter in the `GPT_Delay_Millisecs_H` function represents the time delay
 * in milliseconds that you want the function to wait for. This delay is achieved using a
 * general-purpose timer (GPT) configured with a specific period based on the provided delay value.
 */
void GPT_Delay_Millisecs_H(uint32_t delay); 

/**
 * @fn void GPT_Delay_Microseconds(GPTIMER_Config_t *gptimer, uint32_t delay)
 * 
 * @brief The function `GPT_Delay_Microseconds` generates hardware delay in microseconds.
 * 
 * @details It initializes a general-purpose timer with a specified period and prescalar, 
 * then waits for a specified delay in microseconds.
 * 
 * @param GPTIMER_Config_t The `GPTIMER_Config_t` parameter in the `GPT_Delay_Microseconds` function is a struct that
 * contains gpt_num, mode, interrupt_en, period, prescalar, dutycycle, cnt_en, capture_val, output_en.
 * 
 * @param delay The `delay` parameter in the `GPT_Delay_Microseconds` function represents the time
 * delay in microseconds. This function calculates the necessary period and prescalar values based on the provided 
 * delay to configure the timer accordingly.
 */
void GPT_Delay_Microseconds(GPTIMER_Config_t *gptimer, uint32_t delay);

/**
 * @fn void GPT_Delay_Microsecs_H(uint32_t delay)
 * 
 * @brief The function `GPT_Delay_Microsecs_H` generates hardware delay in microseconds
 * 
 * @details The function `GPT_Delay_Microsecs_H` initializes a general-purpose timer with a specified 
 * delay in microseconds and waits until the timer reaches zero.
 * 
 * @param delay The `delay` parameter in the `GPT_Delay_Microsecs_H` function represents the time delay
 * in microseconds that you want the function to wait for. This delay is achieved using a
 * general-purpose timer (GPT) configured with a specific period based on the provided delay value.
 */
void GPT_Delay_Microsecs_H(uint32_t delay);

// void waitCycles(GPTIMER_Config_t *gptimer, int delayCycles,int prescalar);

#ifdef __cplusplus
}
#endif

#endif