#include <cstddef>

void * operator new(size_t n);
void operator delete(void * p);
